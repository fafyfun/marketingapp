<?php
/**
 * Created by PhpStorm.
 * User: fawaz
 * Date: 4/12/16
 * Time: 1:59 PM
 */
?>
<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Basic Form</h2>
        <ol class="breadcrumb">
            <li>
                <a href="index.html">Home</a>
            </li>
            <li>
                <a>Forms</a>
            </li>
            <li class="active">
                <strong>Basic Form</strong>
            </li>
        </ol>
    </div>
    <div class="col-lg-2">

    </div>
</div>
<div class="wrapper wrapper-content animated fadeInRight">

    <div class="row">

        <?php if(isset($link)){ ?>
        <div class="col-lg-12">

            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>All form elements
                        <small>With custom checbox and radion elements.</small>
                    </h5>

                </div>
                <div class="ibox-content">
                    <a class="btn btn-success btn-facebook" href="<?php echo $link ?>">
                        <i class="fa fa-facebook"> </i> Sign in with Facebook
                    </a>
                </div>
            </div>

        </div>


        <?php }else{ ?>

        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>All form elements
                        <small>With custom checbox and radion elements.</small>
                    </h5>

                </div>
                <div class="ibox-content">
                    <?php

                    $attributes = array('class' => 'form-horizontal', 'id' => 'myform');

                    echo form_open('', $attributes) ?>
                    <div class="form-group"><label class="col-sm-2 control-label">Page</label>

                        <div class="col-sm-10">

                            <select id="profile" class="form-control m-b" name="page">
                                <?php foreach ($pages as $value) {

                                    echo '<option value="' . $value['id'] . '">' . $value['name'] . '</option>';


                                } ?>

                            </select>
                        </div>
                    </div>
                    <div class="hr-line-dashed"></div>

                    <div class="form-group">
                        <div class="col-sm-4 col-sm-offset-2">
                            <button class="btn btn-white" type="submit">Cancel</button>
                            <button class="btn btn-primary" type="submit">Save changes</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <?php } ?>

    </div>
</div>
<div class="footer">
    <div class="pull-right">
        10GB of <strong>250GB</strong> Free.
    </div>
    <div>
        <strong>Copyright</strong> Example Company &copy; 2014-2015
    </div>
</div>