<?php
/**
 * Created by PhpStorm.
 * User: fawaz
 * Date: 4/1/16
 * Time: 3:43 PM
 */
?>


</div>
</div>

<!-- Mainly scripts -->
<script src="<?php echo base_url() ?>/assets/js/jquery-2.1.1.js"></script>
<script src="<?php echo base_url() ?>/assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>/assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="<?php echo base_url() ?>/assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Flot -->
<script src="<?php echo base_url() ?>/assets/js/plugins/flot/jquery.flot.js"></script>
<script src="<?php echo base_url() ?>/assets/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
<script src="<?php echo base_url() ?>/assets/js/plugins/flot/jquery.flot.spline.js"></script>
<script src="<?php echo base_url() ?>/assets/js/plugins/flot/jquery.flot.resize.js"></script>
<script src="<?php echo base_url() ?>/assets/js/plugins/flot/jquery.flot.pie.js"></script>

<!-- Peity -->
<script src="<?php echo base_url() ?>/assets/js/plugins/peity/jquery.peity.min.js"></script>
<script src="<?php echo base_url() ?>/assets/js/demo/peity-demo.js"></script>

<!-- Custom and plugin javascript -->
<script src="<?php echo base_url() ?>/assets/js/inspinia.js"></script>
<script src="<?php echo base_url() ?>/assets/js/plugins/pace/pace.min.js"></script>

<!-- jQuery UI -->
<script src="<?php echo base_url() ?>/assets/js/plugins/jquery-ui/jquery-ui.min.js"></script>

<!-- GITTER -->
<script src="<?php echo base_url() ?>/assets/js/plugins/gritter/jquery.gritter.min.js"></script>

<!-- EayPIE -->
<script src="<?php echo base_url() ?>/assets/js/plugins/easypiechart/jquery.easypiechart.js"></script>

<!--    &lt;!&ndash; Sparkline &ndash;&gt;
    <script src="<?php echo base_url() ?>/assets/js/plugins/sparkline/jquery.sparkline.min.js"></script>-->

<!--    &lt;!&ndash; Sparkline demo data  &ndash;&gt;
    <script src="<?php echo base_url() ?>/assets/js/demo/sparkline-demo.js"></script>-->

<!-- ChartJS-->
<script src="<?php echo base_url() ?>/assets/js/plugins/chartJs/Chart.min.js"></script>

<?php if ( $page == "Dashboard") {

   if($google['sub'] == "Google"){
    $i =0;
foreach ($google['resultData'] as $record){ $i++;

    ?>



<script>
    $(document).ready(function() {

        var lineData = {
            labels: <?php echo $record['valueRange'] ?>,
            datasets: [
                {
                    label: "Test",
                    fillColor: "rgba(70,79,136,0.5)",
                    strokeColor: "rgba(70,79,136,1)",
                    pointColor: "rgba(70,79,136,1)",
                    title:"Completed Order",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(220,220,220,1)",
                    data: <?php echo $record['numUser'] ?>
                },
                {
                    label: "Example dataset",
                    fillColor: "rgba(26,179,148,0.5)",
                    strokeColor: "rgba(26,179,148,0.7)",
                    pointColor: "rgba(26,179,148,1)",
                    title:"Completed Order",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(26,179,148,1)",
                    data: <?php echo $record['numPageViews'] ?>
                }
            ]
        };

        var lineOptions = {
            scaleShowGridLines: true,
            showLegend: true,
            scaleGridLineColor: "rgba(0,0,0,.05)",
            scaleGridLineWidth: 1,
            bezierCurve: true,
            bezierCurveTension: 0.4,
            pointDot: true,
            pointDotRadius: 4,
            pointDotStrokeWidth: 1,
            pointHitDetectionRadius: 20,
            datasetStroke: true,
            datasetStrokeWidth: 2,
            datasetFill: true,
            responsive: true,
        };


        var ctx = document.getElementById("lineChart<?php echo $i ?>").getContext("2d");
        var myNewChart = new Chart(ctx).Line(lineData, lineOptions);

    });
</script>

<script>
    $(document).ready(function() {


        var doughnutData = [
            {
                value: <?php echo $record['visitor'][0][1] ?>,
                color: "#a3e1d4",
                highlight: "#1ab394",
                label: "Returning"
            },
            {
                value: <?php echo $record['visitor'][1][1] ?>,
                color: "#dedede",
                highlight: "#1ab394",
                label: "New"
            },

        ];

        var doughnutOptions = {
            segmentShowStroke: true,
            segmentStrokeColor: "#fff",
            segmentStrokeWidth: 2,
            percentageInnerCutout: 45, // This is 0 for Pie charts
            animationSteps: 100,
            animationEasing: "easeOutBounce",
            animateRotate: true,
            animateScale: false,
        };

        var ctx = document.getElementById("doughnutVisitors<?php echo $i ?>").getContext("2d");
        var DoughnutChart = new Chart(ctx).Doughnut(doughnutData, doughnutOptions);

        var doughnutData1 = [
            /*            {
             value: 7,
             color: "#AF86EE",
             highlight: "#1ab394",
             label: "(not set)"
             },*/
            {
                value:<?php echo (isset($record['deviceBreak'][1][1])?$record['deviceBreak'][1][1]:0)  ?>,
                color: "#FD2149",
                highlight: "#1ab394",
                label: "Android"
            },
            {
                value:<?php echo (isset($record['deviceBreak'][4][1])?$record['deviceBreak'][4][1]:0)  ?>,
                color: "#F65452",
                highlight: "#1ab394",
                label: "Mac"
            },  {
                value:<?php echo (isset($record['deviceBreak'][5][1])?$record['deviceBreak'][5][1]:0)  ?>,
                color: "#2958E8",
                highlight: "#1ab394",
                label: "Win"
            },  {
                value: <?php echo (isset($record['deviceBreak'][6][1])?$record['deviceBreak'][6][1]:0)  ?>,
                color: "#D10F0F",
                highlight: "#1ab394",
                label: "Win Phone"
            },  {
                value: <?php echo (isset($record['deviceBreak'][7][1])?$record['deviceBreak'][7][1]:0)  ?>,
                color: "#9D948D",
                highlight: "#1ab394",
                label: "iOS"
            },

        ];

        var doughnutOptions1 = {
            segmentShowStroke: true,
            segmentStrokeColor: "#fff",
            segmentStrokeWidth: 2,
            percentageInnerCutout: 45, // This is 0 for Pie charts
            animationSteps: 100,
            animationEasing: "easeOutBounce",
            animateRotate: true,
            animateScale: false,
        };

        var ctx = document.getElementById("doughnutDevices<?php echo $i ?>").getContext("2d");
        var DoughnutChart = new Chart(ctx).Doughnut(doughnutData1, doughnutOptions1);



    });
</script>

<?php }}

    if($fb['sub']=="FB"){

       $x=0;

       foreach ($fb['fbDashboardRecords'] as $item) { ?>


       <script>
           $(document).ready(function() {

               var lineData = {
                   labels: <?php echo $item['valueRange'] ?>,
                   datasets: [
                       {
                           label: "Test",
                           fillColor: "rgba(70,79,136,0.5)",
                           strokeColor: "rgba(70,79,136,1)",
                           pointColor: "rgba(70,79,136,1)",
                           title:"Completed Order",
                           pointStrokeColor: "#fff",
                           pointHighlightFill: "#fff",
                           pointHighlightStroke: "rgba(220,220,220,1)",
                           data: <?php echo $item['like'] ?>
                       },
                       {
                           label: "Example dataset",
                           fillColor: "rgba(26,179,148,0.5)",
                           strokeColor: "rgba(26,179,148,0.7)",
                           pointColor: "rgba(26,179,148,1)",
                           title:"Completed Order",
                           pointStrokeColor: "#fff",
                           pointHighlightFill: "#fff",
                           pointHighlightStroke: "rgba(26,179,148,1)",
                           data: <?php echo $item['reach'] ?>
                       }
                   ]
               };

               var lineOptions = {
                   scaleShowGridLines: true,
                   showLegend: true,
                   scaleGridLineColor: "rgba(0,0,0,.05)",
                   scaleGridLineWidth: 1,
                   bezierCurve: true,
                   bezierCurveTension: 0.4,
                   pointDot: true,
                   pointDotRadius: 4,
                   pointDotStrokeWidth: 1,
                   pointHitDetectionRadius: 20,
                   datasetStroke: true,
                   datasetStrokeWidth: 2,
                   datasetFill: true,
                   responsive: true,
               };


               var ctx = document.getElementById("lineChartfb<?php echo $x ?>").getContext("2d");
               var myNewChart = new Chart(ctx).Line(lineData, lineOptions);

           });
       </script>


<?php $x++;  } }



} elseif ($page == "Details"){ ?>

    <script>

        $(document).ready(function() {

            var lineData = {
                labels:  <?php echo $valueRange ?>,
                datasets: [
                    {
                        label: "Example dataset",
                        fillColor: "rgba(220,220,220,0.5)",
                        strokeColor: "rgba(220,220,220,1)",
                        pointColor: "rgba(220,220,220,1)",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(220,220,220,1)",
                        data: <?php echo $numUser ?>
                    },
                    {
                        label: "Example dataset",
                        fillColor: "rgba(26,179,148,0.5)",
                        strokeColor: "rgba(26,179,148,0.7)",
                        pointColor: "rgba(26,179,148,1)",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(26,179,148,1)",
                        data:<?php echo $numPageViews ?>
                    }
                ]
            };

            var lineOptions = {
                scaleShowGridLines: true,
                scaleGridLineColor: "rgba(0,0,0,.05)",
                scaleGridLineWidth: 1,
                bezierCurve: true,
                bezierCurveTension: 0.4,
                pointDot: true,
                pointDotRadius: 4,
                pointDotStrokeWidth: 1,
                pointHitDetectionRadius: 20,
                datasetStroke: true,
                datasetStrokeWidth: 2,
                datasetFill: true,
                responsive: true,
            };


            var ctx = document.getElementById("lineChart").getContext("2d");
            var myNewChart = new Chart(ctx).Line(lineData, lineOptions);

        });

    </script>

<?php } elseif ($page == "getId"){ ?>

    <script>

        var profile = 0

        $('#profile').on('change', function() {
            profile = this.value ; // or $(this).val()

            $.ajax({
                type: "POST",
                dataType: "json",
                url: "<?php echo base_url().'google/getWebProfileId'?>", //Relative or absolute path to response.php file
                data: {'prof_id': profile},
                success: function (data) {

                    var sel = $("#property");
                    sel.empty();
                    for (var i=0; i<data.length; i++) {
                        sel.append('<option value="' + data[i].id + '">' + data[i].name + '</option>');
                    }

                }
            });

        });


    </script>

<?php } elseif ($page == "Facebook"){ ?>

    <script>

        $(document).ready(function() {

            var lineData = {
                labels:  <?php echo $valueRange ?>,
                datasets: [
                    {
                        label: "Example dataset",
                        fillColor: "rgba(220,220,220,0.5)",
                        strokeColor: "rgba(220,220,220,1)",
                        pointColor: "rgba(220,220,220,1)",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(220,220,220,1)",
                        data: <?php echo $like ?>
                    },
                    {
                        label: "Example dataset",
                        fillColor: "rgba(26,179,148,0.5)",
                        strokeColor: "rgba(26,179,148,0.7)",
                        pointColor: "rgba(26,179,148,1)",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(26,179,148,1)",
                        data:<?php echo $reach ?>
                    }
                ]
            };

            var lineOptions = {
                scaleShowGridLines: true,
                scaleGridLineColor: "rgba(0,0,0,.05)",
                scaleGridLineWidth: 1,
                bezierCurve: true,
                bezierCurveTension: 0.4,
                pointDot: true,
                pointDotRadius: 4,
                pointDotStrokeWidth: 1,
                pointHitDetectionRadius: 20,
                datasetStroke: true,
                datasetStrokeWidth: 2,
                datasetFill: true,
                responsive: true,
            };


            var ctx = document.getElementById("lineChart").getContext("2d");
            var myNewChart = new Chart(ctx).Line(lineData, lineOptions);

        });

    </script>

<?php } //elseif ($page == "Details"){ ?>

</body>
</html>