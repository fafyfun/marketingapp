<?php

/**
 * Created by PhpStorm.
 * User: fawaz
 * Date: 4/12/16
 * Time: 3:10 PM
 */
class Facebookdata_model extends CI_Model
{

    public function __construct() {

        parent::__construct();
        $this->load->database();

    }

    public function create_facebook_page($user_id, $cred) {

        $cred['user_id'] = $user_id;

        return $this->db->insert('facebook_pages', $cred);

    }

    public function create_facebook_access($user_id, $cred) {

        $data = array(
            'user_id'   => $user_id,
            'accessToken' => $cred,
            'status'=> 1

        );

        return $this->db->insert('facebook_access', $data);

    }

    public function getFBAccessCode($userid)
    {
        $this->db->from('facebook_access');
        $this->db->where('user_id', $userid);
        $this->db->where('status', 1);
        return $this->db->get()->row();

    }

    public function getfacebookpage($userid)
    {
        $this->db->from('facebook_pages');
        $this->db->where('user_id', $userid);
        $this->db->where('status', 1);
        return $this->db->get()->result();
    }

    public function getacessCode($profileid,$userid)
    {
        $this->db->from('facebook_pages');
        $this->db->where('user_id', $userid);
        $this->db->where('page_id', $profileid);
        $this->db->where('status', 1);
        return $this->db->get()->result();
    }


}