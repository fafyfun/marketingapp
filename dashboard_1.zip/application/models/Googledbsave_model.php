<?php

/**
 * Created by PhpStorm.
 * User: fawaz
 * Date: 4/7/16
 * Time: 4:59 PM
 */
class Googledbsave_model extends CI_Model
{
    public function __construct() {

        parent::__construct();
        $this->load->database();

    }


    public function create_google_cred($user_id, $cred) {

        $data = array(
            'user_id'   => $user_id,
            'access_token'      => $cred['access_token'],
            'token_type'   => $cred['token_type'],
            'expires_in' => $cred['expires_in'],
            'refresh_token' =>$cred['refresh_token'],
            'created' => $cred['created']
        );

        return $this->db->insert('google_credential', $data);

    }

    public function get_google_cred($user_id) {

        $this->db->from('google_credential');
        $this->db->where('user_id', $user_id);
        return $this->db->get()->row();

    }

    public function update_google_cred($user_id,$data) {

        $this->db->where('user_id', $user_id);
        return  $this->db->update('google_credential', $data);


    }

    public function create_google_prof($user_id, $cred) {

        $data = array(
            'user_id'   => $user_id,
            'account_id'      => $cred['account_id'],
            'prop_id'   => $cred['account_id'],
            'web_id' => $cred['web_id'],
            'status' =>$cred['status'],

        );

        return $this->db->insert('google_profile', $data);

    }


    public function getProfile($user_id)
    {
        $this->db->select('web_id');
        $this->db->from('google_profile');
        $this->db->where('user_id', $user_id);
        $this->db->where('status', 1);
        return $this->db->get()->result();

    }


}