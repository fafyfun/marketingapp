<?php session_start();


	require("../db_connection/db_connect.php");
	
	
	if($_SESSION['sadmin']==1 && $_GET['reseller_id']!="" || $_GET['reseller_id']!=1){
		
		
		$sql="SELECT * FROM adminuser WHERE id=".$_GET['reseller_id']." ";
	
		$result = mysql_query($sql);
				
		while ($userarrData = mysql_fetch_array($result)) {
		$_SESSION['id'] = $userarrData['id']; 
		$_SESSION['useraccount_login'] = 1;
		header("location: http://dashboard.digitalglare.com.au");
		exit;
		
		}
		
		
	}else{
		exit;
		
	}
	
	
	 
?>
