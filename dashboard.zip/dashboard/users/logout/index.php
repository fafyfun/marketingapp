<?php session_start();



if($_SESSION['useraccount_login']==1){	
	$_SESSION['id'] = 1;
	unset($_SESSION['useraccount_login']);	
	header("location:/users");
	exit;
	
}else{
session_destroy();
header("location:/login");
}
?>
