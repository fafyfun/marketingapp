<?php session_start();
if($_SESSION['sadmin']!= 1 || $_GET["userid"]==1){
	header("location:/");
	exit;
}


require("../../db_connection/db_connect.php");





$uid=$_GET["userid"];



if($_POST['Save']=="Update"){

$Uname = mysql_escape_string($_POST['txtUname']);
$Email = $_POST['txtEmail'];
$Pass = $_POST['txtPass'];
$RPass = $_POST['txtRPass'];

$Contact = $_POST['txtContact'];
$Company = $_POST['txtCompany'];

$Fname = $_POST['txtFname'];
$Lname = $_POST['txtLname'];
$Dusername = $_POST['Dusername'];
$DEmail = $_POST['DEmail'];

$statusChange = $_POST['txtActive'];
if($statusChange=="on"){
	$statusChange = 0;
}else{
	$statusChange = 1;
}

//var_dump($statusChange);

$id = $_POST['hid'];


if(empty($Fname)){
$req="All field are requied";
$errorFnamem="First Name Cannot be blank.";
$errorFname=1;
$error=1;
}else{
$Fnameerror=0;
}

if(empty($Uname)){
$req="All field are requied";
$errorname="User Name Cannot be blank - Ex:joinsmith";
$errornamest=1;
$error=1;
}else{
$Uerror=0;
}
if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $Email)){
$req="All field are requied";
$erroremail="Invalid Email - Ex: jhonsmith@domainname.com";
$erroremailst=1;
$error=1;
}else{
$Eerror=0;
}


if(empty($Company)){
$req="All field are requied";
$errorcompany="User Name cannot be blank - Ex:joinsmith";
$errorcompany=1;
$error=1;
}else{
$errorcompany=0;
}

if($Contact!=""){
			$nalw = array("+", "-", ".");
			$Mobile = trim(str_replace($nalw, "",$Contact));
			 if (!ctype_digit($Contact) || strlen($Contact) < 10) 
			{ 
				$errorcontact=1;
				$error=1;
			}else{		
				 $errorcontact=0;
			}
	   }
	   
	   
if(!empty($Pass)){

	if(($Pass != $RPass )){
	$req="All field are requied";
	$errorRPassm="Passwords do not match.";
	$errorRPass=1;
	$error=1;
	}else{
	$RPasserror=0;
	}
}



    $Pass = md5($Pass);
    $RPass = md5($RPass);
	
$Unamen= str_replace (" ", "", $Uname);
$Passn= str_replace (" ", "", $Pass);

if($Unamen<>$Dusername){
$adduser = "SELECT * FROM  adminuser where username = '$Unamen' ";
$result = mysql_query($adduser) or die(mysql_error());
if(mysql_num_rows($result)>0) {
	 $Uerror = 1;	
	 $alreadymassage = " Sorry.. This User Name already exist.";
	 $error=1;
}
}
if($Email<>$DEmail){
$adduser = "SELECT * FROM  adminuser where email= '$Email' ";
$result = mysql_query($adduser) or die(mysql_error());
if(mysql_num_rows($result)>0) {
	 $Uerror = 2;	
	 $alreadymassage = " Sorry.. This Email allredy registered with user name.";
	 $error=1;
}
}
// check user permission for update this user ..
			 
if($Fnameerror=="0" && $Uerror=="0" && $Eerror=="0" && $errorRPass!=1 &&  $errorcompany=="0" && $errorcontact !=1 && $id != 1){


		$sql = "UPDATE adminuser SET  username='$Unamen' ,first_name='$Fname', last_name='$Lname', email='$Email' , company='$Company', status='$statusChange', contact='$Contact'" ;
		if(trim($_POST['txtPass'])!='') {
			$sql .= ", password='$Passn' ";
			
		}
		$sql .= " WHERE id='$id'  ";
		$result = mysql_query($sql); 
		//echo $sql;
		$massage = "User account details have been updated.";
		
	} else {
		//header("location:../dashboard.php");
	}
//header("Location: edit_user.php?msg=save&&uid=$uid"); 

	
	$massageclass = 4;
	//header("location: users.php");
}

	
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard | Edit User</title>

    <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/font-awesome/css/font-awesome.css" rel="stylesheet">

   
    <!-- Data Tables -->
    <link href="/assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="/assets/css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
    <link href="/assets/css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">
    

    <link href="/assets/css/animate.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
    
    

</head>

<body>

<div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
            <ul id="side-menu" class="nav">
                
<?php if($_SESSION['id']!= 1 && $_SESSION['useraccount_login']!=1){ ?>
               <li class="">
                    <a href=""><i class="fa fa-google"></i> <span class="nav-label">Google Analytics</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse" aria-expanded="false" style="height: 0px;">
                        <li><a href="/google/index">Dashboard</a></li>
                        <li><a href="/google/getProfileIDs">Add Accounts</a></li>
                    </ul>
                </li>
                <li class="">
                    <a href="#"><i class="fa fa-facebook-square"></i> <span class="nav-label">Facebook</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse" aria-expanded="false" style="height: 0px;">
                        <li><a href="/facebook/dashboard">Dashboard</a></li>
                        <li><a href="/facebook/selectProfile">Add Pages</a></li>
                    </ul>
                </li>
    <?php } ?>
                
                <?php if($_SESSION['sadmin']== 1){ ?>
                <li class="active">
                    <a href="#"><i class="fa fa-users"></i> <span class="nav-label">Users</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse" aria-expanded="false" style="height: 0px;">
                        <li><a href="/users">View Users</a></li>
                        <li><a href="/users/add">Add New User</a></li>
                    </ul>
                </li>
                <?php } ?>
    
            </ul>
                
            </div>
        </nav>
        

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
           
        </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <span class="m-r-sm text-muted welcome-message">Welcome <?php echo ucfirst($_SESSION['first_name']);?></span>
                </li>
                
                
                <li>
                    <a href="../logout">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>

        </nav>
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Edit User</h2>                    
                </div>
                
                
                 <?php if (!empty($alreadymassage)){ ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo $alreadymassage;?>
				</div>
			</div>
		<?php } ?>


 <?php if (!empty($massage)){ ?>
			<div class="col-md-12">
				<div class="alert alert-success" role="alert">
					<?php echo $massage;?>
				</div>
			</div>
		<?php } ?>

               
            </div>
        <?php
		
            
			$strFilterSql	= "SELECT * FROM adminuser WHERE id='$uid' ";
		
			
                $selectedQuery	= mysql_query($strFilterSql) or die("Invalid Id");
			
				while ($arrData = mysql_fetch_array($selectedQuery)) {
						$user_id=$arrData['id'];		// 	
						$username = $arrData['username']; // 		
						$email = $arrData['email']; // 
						$permission = $arrData['permission']; //
						$Company = $arrData['company']; //
						$Contact = $arrData['contact']; //						
						
						$status = $arrData['status'];
						$sadmin = $arrData['sadmin'];  
						$pass = $arrData['password']; 
						$Fname = $arrData['first_name']; 
						$Lname = $arrData['last_name'];						
						if($permission=="1"&& $sadmin=="1"){
						$permissionl="Super Admin";
						}if($permission=="1" && $sadmin=="0"){
						$permissionl="Admin";
						}
						if($permission=="0"){
						$permissionl="User";
						}
					    if($status=="1"){
						$statusl="Active";
						}if($status=="0"){
						$statusl="Block";
						}if($sadmin=="1"){
						$statusl="Active";
						}
                        ?>
     <form id="form1" name="form1" method="post" action="" class="form-horizontal">
                                <div class="<?php if($errorFname==0){
		  			echo "form-group";
					} else if($errorFname==1){
					echo "form-group has-error"; 
					} ?>"> <label class="col-sm-2 control-label">First Name:*</label>

                                    <div class="col-sm-2">                                   
								    <input  name="txtFname" type="text" 
                                     id="txtFname" size="25" maxlength="10" value="<?php echo ucwords($Fname) ;?>" class="form-control"/>
								  </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label">Last Name:</label>
                                    <div class="col-sm-2"><input name="txtLname" type="text" class="form-control" id="txtLname" size="25" maxlength="10" value="<?php echo ucwords($Lname) ;?>" />
                                    </div>
                                </div>
                                
                                
                                
                                 <div class="hr-line-dashed"></div>
                                
                                <div class="<?php if($errorcompany==0){
		  			echo "form-group";
					} else if($errorcompany==1){
					echo "form-group has-error"; 
					} ?>">
                    <label class="col-sm-2 control-label">Company:* </label>

                                    <div class="col-sm-2">
                                    <input name="txtCompany" type="text" id="txtCompany"  class="form-control" size="25" value="<?php echo ucwords($Company) ;?>"/>
                                       
                                    </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                
                                <div class="<?php if($errorcontact==0){
		  			echo "form-group";
					} else if($errorcontact==1){
					echo "form-group has-error"; 
					} ?>">
                    <label class="col-sm-2 control-label">Contact Number: </label>

                                    <div class="col-sm-2">
                                    <input name="txtContact" type="text" id="txtContact"  class="form-control" size="25" value="<?php echo ucwords($Contact) ;?>"/>
                                       
                                    </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                
                                
                                <div class="<?php if($errornamest==0){
		  			echo "form-group";
					} else if($errornamest==1){
					echo "form-group has-error"; 
					} ?>">
                    <label class="col-sm-2 control-label">Username:* </label>

                                    <div class="col-sm-2">
                                    <input name="txtUname" type="text" class="form-control"                                     
                                    id="txtUname" value="<?php echo $username ;?>" size="25" maxlength="20"/>	</div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                <div class="<?php if($erroremailst==0){
		  			echo "form-group";
					} else if($erroremailst==1){
					echo "form-group has-error"; 
					} ?>"><label class="col-sm-2 control-label">Email:*</label>

                                    <div class="col-sm-2">
                                    <input name="txtEmail" type="text" class="form-control" id="txtEmail" value="<?php echo $email ;?>" size="25"/>                  
                                    
								  </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                <div class="<?php if($errorRPass==0){
		  			echo "form-group";
					} else if($errorRPass==1){
					echo "form-group has-error"; 
					} ?>"><label class="col-sm-2 control-label">Password:*</label>

                                    <div class="col-sm-2">
                                    <input name="txtPass" type="password" class="form-control" id="txtPass" value="" size="25"/>	
                    
                                   </div>
                                </div>
                                
                                
                                 <div class="hr-line-dashed"></div>
                                
                                <div class="<?php if($errorRPass==0){
		  			echo "form-group";
					} else if($errorRPass==1){
					echo "form-group has-error"; 
					} ?>">
                    <label class="col-sm-2 control-label">Re-enter Password:* </label>

                                    <div class="col-sm-2">
                                    <input name="txtRPass" type="password" id="txtRPass" class="form-control" size="25" value="" />
                                       
                                    </div>
                                </div>
                                                               
                                
                                   <div class="hr-line-dashed"></div>
                                
                                <div class="form-group">
                    <label class="col-sm-2 control-label">Block this user</label>

                                    <div class="col-sm-2">
                                    <input name="txtActive" type="checkbox" id="txtActive" class="form-control" <?php if($status==0){?> checked <?php }?>/>
                                       
                                    </div>
                                </div>
                                
                                
                               
                                <div class="hr-line-dashed"></div>
                               
                                                       
                                
                          
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-white" type="submit">Cancel</button>
                                        
                            <input name="Save" type="submit"   class="btn btn-primary" id="Save" value="Update" />
                          <input type="hidden" value="Save" />
                          
                                        
                                            <input type="hidden" name="hid" id="hid" value="<?php echo $uid;?>"/>
								    <input type="hidden" name="Dusername" id="Dusername" value="<?php echo $username;?>"/>	
                                    							    <input type="hidden" name="DEmail" id="DEmail" value="<?php echo $email;?>"/>	
                                    </div>
                                </div>
                            </form>
                            
        
         <?php }?>  
        
        
        <div class="footer">
            <div class="pull-right">
              
            </div>
            <div>
                
            </div>
        </div>

        </div>
        </div>
        
        
        <!-- Mainly scripts -->
    <script src="/assets/js/jquery-2.1.1.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>
    <script src="/assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="/assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="/assets/js/plugins/jeditable/jquery.jeditable.js"></script>

    <!-- Data Tables -->
    <script src="/assets/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="/assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/js/plugins/dataTables/dataTables.responsive.js"></script>
    <script src="/assets/js/plugins/dataTables/dataTables.tableTools.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="/assets/js/inspinia.js"></script>
    <script src="/assets/js/plugins/pace/pace.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() {
            $('.dataTables-example').dataTable({
                responsive: true,
                "dom": 'T<"clear">lfrtip',
                "tableTools": {
                    "sSwfPath": "js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
                }
            });

            /* Init DataTables */
            var oTable = $('#editable').dataTable();

            /* Apply the jEditable handlers to the table */
            oTable.$('td').editable( '../example_ajax.php', {
                "callback": function( sValue, y ) {
                    var aPos = oTable.fnGetPosition( this );
                    oTable.fnUpdate( sValue, aPos[0], aPos[1] );
                },
                "submitdata": function ( value, settings ) {
                    return {
                        "row_id": this.parentNode.getAttribute('id'),
                        "column": oTable.fnGetPosition( this )[2]
                    };
                },

                "width": "90%",
                "height": "100%"
            } );


        });

        function fnClickAddRow() {
            $('#editable').dataTable().fnAddData( [
                "Custom row",
                "New row",
                "New row",
                "New row",
                "New row" ] );

        }
    </script>
<style>
    body.DTTT_Print {
        background: #fff;

    }
    .DTTT_Print #page-wrapper {
        margin: 0;
        background:#fff;
    }

    button.DTTT_button, div.DTTT_button, a.DTTT_button {
        border: 1px solid #e7eaec;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }
    button.DTTT_button:hover, div.DTTT_button:hover, a.DTTT_button:hover {
        border: 1px solid #d2d2d2;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }

    .dataTables_filter label {
        margin-right: 5px;

    }
</style>


        </body>
</html>
