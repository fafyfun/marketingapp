<?php session_start();


if($_SESSION['sadmin']!= 1){
	header("location:/");
	exit;
}
require("../db_connection/db_connect.php");
	
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard | Users</title>

    <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/font-awesome/css/font-awesome.css" rel="stylesheet">

   
    <!-- Data Tables -->
    <link href="/assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="/assets/css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
    <link href="/assets/css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">
    

    <link href="/assets/css/animate.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
    
    

</head>

<body>

<div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
            <ul id="side-menu" class="nav">
                
<?php if($_SESSION['id']!= 1 && $_SESSION['useraccount_login']!=1){ ?>
               <li class="">
                    <a href=""><i class="fa fa-google"></i> <span class="nav-label">Google Analytics</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse" aria-expanded="false" style="height: 0px;">
                        <li><a href="/google/index">Dashboard</a></li>
                        <li><a href="/google/getProfileIDs">Add Accounts</a></li>
                    </ul>
                </li>
                <li class="">
                    <a href="#"><i class="fa fa-facebook-square"></i> <span class="nav-label">Facebook</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse" aria-expanded="false" style="height: 0px;">
                        <li><a href="/facebook/dashboard">Dashboard</a></li>
                        <li><a href="/facebook/selectProfile">Add Pages</a></li>
                    </ul>
                </li>
            <?php } ?>
                
                <?php if($_SESSION['sadmin']== 1){ ?>
                <li class="active">
                    <a href="#"><i class="fa fa-users"></i> <span class="nav-label">Users</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse" aria-expanded="false" style="height: 0px;">
                        <li><a href="/users">View Users</a></li>
                        <li><a href="/users/add">Add New User</a></li>
                    </ul>
                </li>
                <?php } ?>
    
            </ul>
                
            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
           
        </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <span class="m-r-sm text-muted welcome-message">Welcome <?php echo ucfirst($_SESSION['first_name']);?></span>
                </li>
                
                
                <li>
                    <a href="/users/logout">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>

        </nav>
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Users</h2>                    
                </div>
                <div class="col-lg-2">

                </div>
            </div>
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    
                    <div class="ibox-content">

                    <table class="table table-striped table-bordered table-hover dataTables-example" >
                    <thead>
                    <tr>
                        <th>Name</th>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>Company</th>
                        <th>User Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    
                    
                    <?php 
                    
                    $strFilterSql	= "SELECT * FROM adminuser ";
					$selectedQuery	= mysql_query($strFilterSql);
						
				
				while ($arrData = mysql_fetch_array($selectedQuery)) {
						$user_id = $arrData['id'];		// 
						$username = $arrData['username']; // 		
						$email = $arrData['email']; // 
						$permission = $arrData['permission']; 
						$first_name = $arrData['first_name'];
						$last_name = $arrData['last_name'];  
						$company = $arrData['company']; 
						
						
						$status = $arrData['status'];
						$sadmin = $arrData['sadmin'];  
						if($permission=="1"&& $sadmin=="1"){
						$permissionl="Super Admin";
						}if($permission=="1" && $sadmin=="0"){
						$permissionl="Admin";
						}
						if($permission=="0"){
						$permissionl="User";
						}
					    if($status=="1"){
						$statusl="Active";
						}if($status=="0"){
						$statusl="Block";
						}if($sadmin=="1"){
						$statusl="Active";
						}
						
						if ($i%2) {
							$class = 'row1';
						} else {
							$class = 'row2';
						}
						
						$i += 1;
                 
				    ?>
                    <tr class="gradeX">
                        <td><?php echo $username.' '.$last_name;?></td>
                        <td><?php echo $username;?></td>
                        <td><?php echo $email;?></td>
                        <td><?php echo $company;?></td>
                        <td><?php echo $statusl;?></td>
                         <td>
						 <?php if($user_id!=1){?><a href="/users/edit/index.php?userid=<?php echo $user_id ;?>"><i class="fa fa-edit"></i></a>&nbsp&nbsp&nbsp 
                         <a href="../user-account/index.php?reseller_id=<?php echo $user_id ;?>">Login</a>
						 <?php }?></td>
                          <?php } ?>  
                        
                    </tr>
                    
                    
                    </tbody>
                    <tfoot>
                    <tr>
                        <th>Name</th>
                        <th>User Name</th>
                        <th>Email</th>
                        <th>Company</th>
                        <th>User Status</th>
                        <th>Action</th>
                    </tr>
                    </tfoot>
                    </table>

                    </div>
                </div>
            </div>
            </div>
            
        </div>
        <div class="footer">
            <div class="pull-right">
                
            </div>
            <div>
                
            </div>
        </div>

        </div>
        </div>
        
        
        <!-- Mainly scripts -->
    <script src="/assets/js/jquery-2.1.1.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>
    <script src="/assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="/assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="/assets/js/plugins/jeditable/jquery.jeditable.js"></script>

    <!-- Data Tables -->
    <script src="/assets/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="/assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/js/plugins/dataTables/dataTables.responsive.js"></script>
    <script src="/assets/js/plugins/dataTables/dataTables.tableTools.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="/assets/js/inspinia.js"></script>
    <script src="/assets/js/plugins/pace/pace.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() {
            $('.dataTables-example').dataTable({
                responsive: true,
                "dom": 'T<"clear">lfrtip',
                "tableTools": {
                    "sSwfPath": "js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
                }
            });

            /* Init DataTables */
            var oTable = $('#editable').dataTable();

            /* Apply the jEditable handlers to the table */
            oTable.$('td').editable( '../example_ajax.php', {
                "callback": function( sValue, y ) {
                    var aPos = oTable.fnGetPosition( this );
                    oTable.fnUpdate( sValue, aPos[0], aPos[1] );
                },
                "submitdata": function ( value, settings ) {
                    return {
                        "row_id": this.parentNode.getAttribute('id'),
                        "column": oTable.fnGetPosition( this )[2]
                    };
                },

                "width": "90%",
                "height": "100%"
            } );


        });

        function fnClickAddRow() {
            $('#editable').dataTable().fnAddData( [
                "Custom row",
                "New row",
                "New row",
                "New row",
                "New row" ] );

        }
    </script>
<style>
    body.DTTT_Print {
        background: #fff;

    }
    .DTTT_Print #page-wrapper {
        margin: 0;
        background:#fff;
    }

    button.DTTT_button, div.DTTT_button, a.DTTT_button {
        border: 1px solid #e7eaec;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }
    button.DTTT_button:hover, div.DTTT_button:hover, a.DTTT_button:hover {
        border: 1px solid #d2d2d2;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }

    .dataTables_filter label {
        margin-right: 5px;

    }
</style>


        </body>
</html>
