<?php session_start();
if($_SESSION['sadmin']!= 1){
	header("location:/");
}


require("../../db_connection/db_connect.php");




$myusername=$_SESSION['myusername'];
$permission=$_SESSION['permission'];
$subname=$_SESSION['first_name'];
$sadmin=$_SESSION['sadmin'];

if($sadmin=="1" && $permission=="1"){

}






if($_POST['Save']){
$Status=$_POST['mnuStatus'];
$Uname=mysql_escape_string($_POST['txtUname']);
$Company=mysql_escape_string($_POST['txtCompany']);

$Email=$_POST['txtEmail'];
$Pass= $_POST['txtPass'];
$RPass= $_POST['txtRPass'];

$Contact= $_POST['txtContact'];


$Fname=$_POST['txtFname'];
$Lname=$_POST['txtLname'];



if(empty($Fname)){
$req="All field are requied";
$errorFnamem="First Name Cannot be blank.";
$errorFname=1;
$error=1;
}else{
$Fnameerror=0;
}

if(empty($Company)){
$req="All field are requied";
$errorcompany="User Name cannot be blank - Ex:joinsmith";
$errorcompany=1;
$error=1;
}else{
$errorcompany=0;
}

if($Contact!=""){
			$nalw = array("+", "-", ".");
			$Mobile = trim(str_replace($nalw, "",$Contact));
			 if (!ctype_digit($Contact) || strlen($Contact) < 10) 
			{ 
				$errorcontact=1;
				$error=1;
			}else{		
				 $errorcontact=0;
			}
	   }
	   


$Unamen= str_replace (" ", "", $Uname);

if(empty($Uname)){
$req="All field are requied";
$errorname="User Name cannot be blank - Ex:joinsmith";
$errornamest=1;
$error=1;
}else{
$Uerror=0;
}

if (!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $Email)){
$req="All field are requied";
$erroremail="Invalid Email - Ex: jhonsmith@domainname.com";
$erroremailst=1;
$error=1;
}else{
$Eerror=0;
}



$Pass= str_replace (" ", "", $Pass);
$RPass= str_replace (" ", "", $RPass);



if($Pass==""){
$req="All field are requied";
$errorpassm="Password cannot be blank.";
$errorpassst1=1;
$error=1;
}else{
$errorpassst1=0;
}

if($RPass==""){
$req="All field are requied";
$errorRPassm="Passwords do not match.";
$errorRPass=1;
$error=1;
}

if(($errorpassst1==1) && ($errorRPass==1)){
	if(($Pass != $RPass )){
	$req="All field are requied";
	$errorRPassm="Passwords do not match.";
	$errorRPass=1;
	$errorpassst1=1;
	$error=1;
	}else{
	$errorRPass=0;
	//$errorpassst1=0;
	}
}
/*if($Status=="2"){
$req="All field are requied";
$errorStatusm="Please Select User Level.";
$errorStatus=1;
$error=1;
}else{
$Statuserror=0;
}*/





$adduser = "SELECT * FROM  adminuser where username = '$Unamen' ";
$result = mysql_query($adduser) or die(mysql_error());
if(mysql_num_rows($result)>0) {
	 $Uerror = 1;	
	 $alreadymassage .= " Sorry.. This User Name already exist.</br>";
	 $error=1;
	 
}
$adduser = "SELECT * FROM  adminuser where email= '$Email' ";
$result = mysql_query($adduser) or die(mysql_error());
if(mysql_num_rows($result)>0) {
	 $Uerror = 2;	
	 $alreadymassage .= " Sorry.. This Email allredy registered with user name.";
	 $error=1;
}

if($errorRPass!=1  && $errorpassst1=="0" && $Eerror=="0" && $Uerror=="0" && $Fnameerror=="0" && $errorcompany=="0" && $errorcontact !=1 ){
	
	
    $Passn = md5($Pass);


	$adduser = "INSERT INTO adminuser (id,username,first_name,last_name,password,permission,email,date,ip,status,sadmin,company,contact)
	VALUES ('','$Unamen','$Fname' , '$Lname' ,'$Passn' , '1' ,'$Email',NOW(),'$ip','1','0','$Company','$Contact')";
	$result = mysql_query($adduser) or die(mysql_error()); 
	//header("Location: add_user.php?msg=save"); 
	//header("Location: useradok.php?msg=save");
	$massage="You have added a new user";
	$massageclass=4;
	header("location: ../index.php");
}
}
	
?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard | Add New User</title>

    <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/font-awesome/css/font-awesome.css" rel="stylesheet">

   
    <!-- Data Tables -->
    <link href="/assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="/assets/css/plugins/dataTables/dataTables.responsive.css" rel="stylesheet">
    <link href="/assets/css/plugins/dataTables/dataTables.tableTools.min.css" rel="stylesheet">
    

    <link href="/assets/css/animate.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
    
    

</head>

<body>

<div id="wrapper">

        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
            <ul id="side-menu" class="nav">
                
 <?php if($_SESSION['id']!= 1 && $_SESSION['useraccount_login']!=1){ ?>
               <li class="">
                    <a href=""><i class="fa fa-google"></i> <span class="nav-label">Google Analytics</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse" aria-expanded="false" style="height: 0px;">
                        <li><a href="/google/index">Dashboard</a></li>
                        <li><a href="/google/getProfileIDs">Add Accounts</a></li>
                    </ul>
                </li>
                <li class="">
                    <a href="#"><i class="fa fa-facebook-square"></i> <span class="nav-label">Facebook</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse" aria-expanded="false" style="height: 0px;">
                        <li><a href="/facebook/dashboard">Dashboard</a></li>
                        <li><a href="/facebook/selectProfile">Add Pages</a></li>
                    </ul>
                </li>
                <?php } ?>
                
                <?php if($_SESSION['sadmin']== 1){ ?>
                <li class="active">
                    <a href="#"><i class="fa fa-users"></i> <span class="nav-label">Users</span><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level collapse" aria-expanded="false" style="height: 0px;">
                        <li><a href="/users">View Users</a></li>
                        <li><a href="/users/add">Add New User</a></li>
                    </ul>
                </li>
                <?php } ?>
    
            </ul>
                
            </div>
        </nav>
        

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
           
        </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <span class="m-r-sm text-muted welcome-message">Welcome <?php echo ucfirst($_SESSION['first_name']);?></span>
                </li>
                
                
                <li>
                    <a href="../logout">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
            </ul>

        </nav>
        </div>
            <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Add New User</h2>                    
                </div>
                
                
                 <?php if (!empty($alreadymassage)){ ?>
			<div class="col-md-12">
				<div class="alert alert-danger" role="alert">
					<?php echo $alreadymassage;?>
				</div>
			</div>
		<?php } ?>

               
            </div>
        
     <form id="form1" name="form1" method="post" action="" class="form-horizontal">
                                <div class="<?php if($errorFname==0){
		  			echo "form-group";
					} else if($errorFname==1){
					echo "form-group has-error"; 
					} ?>"> <label class="col-sm-2 control-label">First Name:*</label>

                                    <div class="col-sm-2">                                   
								    <input  name="txtFname" type="text" 
                                     id="txtFname" size="25" maxlength="10" value="<?php echo ucwords($Fname) ;?>" class="form-control"/>
								  </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                <div class="form-group"><label class="col-sm-2 control-label">Last Name:</label>
                                    <div class="col-sm-2"><input name="txtLname" type="text" class="form-control" id="txtLname" size="25" maxlength="10" value="<?php echo ucwords($Lname) ;?>" />
                                    </div>
                                </div>
                                
                                
                                
                                 <div class="hr-line-dashed"></div>
                                
                                <div class="<?php if($errorcompany==0){
		  			echo "form-group";
					} else if($errorcompany==1){
					echo "form-group has-error"; 
					} ?>">
                    <label class="col-sm-2 control-label">Company:* </label>

                                    <div class="col-sm-2">
                                    <input name="txtCompany" type="text" id="txtCompany"  class="form-control" size="25" value="<?php echo ucwords($Company) ;?>"/>
                                       
                                    </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                
                                <div class="<?php if($errorcontact==0){
		  			echo "form-group";
					} else if($errorcontact==1){
					echo "form-group has-error"; 
					} ?>">
                    <label class="col-sm-2 control-label">Contact Number: </label>

                                    <div class="col-sm-2">
                                    <input name="txtContact" type="text" id="txtContact"  class="form-control" size="25" value="<?php echo ucwords($Contact) ;?>"/>
                                       
                                    </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                
                                
                                <div class="<?php if($errornamest==0){
		  			echo "form-group";
					} else if($errornamest==1){
					echo "form-group has-error"; 
					} ?>">
                    <label class="col-sm-2 control-label">Username:* </label>

                                    <div class="col-sm-2">
                                    <input name="txtUname" type="text" class="form-control"                                     
                                    id="txtUname" value="<?php echo $Unamen ;?>" size="25" maxlength="20"/>	</div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                <div class="<?php if($erroremailst==0){
		  			echo "form-group";
					} else if($erroremailst==1){
					echo "form-group has-error"; 
					} ?>"><label class="col-sm-2 control-label">Email:*</label>

                                    <div class="col-sm-2">
                                    <input name="txtEmail" type="text" class="form-control" id="txtEmail" value="<?php echo $Email ;?>" size="25"/>                  
                                    
								  </div>
                                </div>
                                
                                <div class="hr-line-dashed"></div>
                                <div class="<?php if($errorpassst1==0){
		  			echo "form-group";
					} else if($errorpassst1==1){
					echo "form-group has-error"; 
					} ?>"><label class="col-sm-2 control-label">Password:*</label>

                                    <div class="col-sm-2">
                                    <input name="txtPass" type="password" class="form-control" id="txtPass" value="" size="25"/>	
                    
                                   </div>
                                </div>
                                
                                
                                 <div class="hr-line-dashed"></div>
                                
                                <div class="<?php if($errorRPass==0){
		  			echo "form-group";
					} else if($errorRPass==1){
					echo "form-group has-error"; 
					} ?>">
                    <label class="col-sm-2 control-label">Re-enter Password:* </label>

                                    <div class="col-sm-2">
                                    <input name="txtRPass" type="password" id="txtRPass" class="form-control" size="25" value="" />
                                       
                                    </div>
                                </div>
                                                               
                                
                               
                                <div class="hr-line-dashed"></div>
                               
                                                       
                                
                          
                                <div class="form-group">
                                    <div class="col-sm-4 col-sm-offset-2">
                                        <button class="btn btn-white" type="submit">Cancel</button>
                                       
                                         <input name="Save" type="submit"   class="btn btn-primary" id="Save" value="Save" />
                                            <input type="hidden" value="Save" />
                                    </div>
                                </div>
                            </form>
                            
        
        
        
        
        <div class="footer">
            <div class="pull-right">
              
            </div>
            <div>
                
            </div>
        </div>

        </div>
        </div>
        
        
        <!-- Mainly scripts -->
    <script src="/assets/js/jquery-2.1.1.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>
    <script src="/assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="/assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="/assets/js/plugins/jeditable/jquery.jeditable.js"></script>

    <!-- Data Tables -->
    <script src="/assets/js/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="/assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script src="/assets/js/plugins/dataTables/dataTables.responsive.js"></script>
    <script src="/assets/js/plugins/dataTables/dataTables.tableTools.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="/assets/js/inspinia.js"></script>
    <script src="/assets/js/plugins/pace/pace.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() {
            $('.dataTables-example').dataTable({
                responsive: true,
                "dom": 'T<"clear">lfrtip',
                "tableTools": {
                    "sSwfPath": "js/plugins/dataTables/swf/copy_csv_xls_pdf.swf"
                }
            });

            /* Init DataTables */
            var oTable = $('#editable').dataTable();

            /* Apply the jEditable handlers to the table */
            oTable.$('td').editable( '../example_ajax.php', {
                "callback": function( sValue, y ) {
                    var aPos = oTable.fnGetPosition( this );
                    oTable.fnUpdate( sValue, aPos[0], aPos[1] );
                },
                "submitdata": function ( value, settings ) {
                    return {
                        "row_id": this.parentNode.getAttribute('id'),
                        "column": oTable.fnGetPosition( this )[2]
                    };
                },

                "width": "90%",
                "height": "100%"
            } );


        });

        function fnClickAddRow() {
            $('#editable').dataTable().fnAddData( [
                "Custom row",
                "New row",
                "New row",
                "New row",
                "New row" ] );

        }
    </script>
<style>
    body.DTTT_Print {
        background: #fff;

    }
    .DTTT_Print #page-wrapper {
        margin: 0;
        background:#fff;
    }

    button.DTTT_button, div.DTTT_button, a.DTTT_button {
        border: 1px solid #e7eaec;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }
    button.DTTT_button:hover, div.DTTT_button:hover, a.DTTT_button:hover {
        border: 1px solid #d2d2d2;
        background: #fff;
        color: #676a6c;
        box-shadow: none;
        padding: 6px 8px;
    }

    .dataTables_filter label {
        margin-right: 5px;

    }
</style>


        </body>
</html>
