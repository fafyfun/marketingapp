<?php    error_reporting(0);
	
	
	define("C_DB_TYPE", "mysqli");            

	define("C_DB_HOST", "localhost");        

	define("C_DB_NAME", "dglk_dashboard-wp");             

	define("C_DB_USER", "dglk_dashboard"); 

	define("C_DB_PASS", "KTpnxf^=Su=p");



	
	 $dbConnection = mysql_connect(C_DB_HOST,C_DB_USER,C_DB_PASS);
	 mysql_select_db(C_DB_NAME, $dbConnection);


?>